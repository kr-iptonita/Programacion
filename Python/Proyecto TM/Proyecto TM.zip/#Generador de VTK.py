#Generador de VTK

import vtk