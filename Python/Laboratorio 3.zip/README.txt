El programa "Laboratorio 3.ipynb" se organiza de la siguiente manera:

1)Importación de datos.
2)Definición de funciónes.
	a)coste.
	b)descenso del gradiente.
3)Aplicación de funciones bajo condiciones iniciales de ajuste y de aprendizaje.
4)Graficación del plano.
5)Impresión de ecuación del plano.
6)Guardado de resultados.
7)Impresión de la grafica de rendimiento.

El programa "Laboratorio 3.ipynb" se elaboró inicialmente en google colaboratory
pero por problemas por el uso del archivo "xyz.csv" solo se usó para poner ideas pero
la ejecución terminó llevandosé a cabo en visual studio code.

JTCA:	Se me hizo dificil la elaboración de la función para el algoritmo del descenso del
	gradiente por el calculo de las derivadas parciales.
VGR:	Las graficas en 3d se complicaron por errores de sintaxis.